package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class OrderDetails extends AppCompatActivity {
    TextView listOrder, priceOrder;
    String list_choice;
    Double sub_price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);
        listOrder = (TextView) findViewById(R.id.listOrder);
        priceOrder = (TextView) findViewById(R.id.priceOrder);

        Bundle bundle = getIntent().getExtras();
        list_choice = bundle.getString("choose");

        sub_price = bundle.getDouble("price");
        listOrder.setText(list_choice);
        priceOrder.setText("Total harga: "+sub_price.toString());

    }


    public void orderMore(View view) {
        Intent intent = new Intent(this,DrinksActivity.class);
        startActivity(intent);
    }

    public void next(View view) {
        Intent intent = new Intent(this,OrderCompleteActivity.class);
        startActivity(intent);
    }
}