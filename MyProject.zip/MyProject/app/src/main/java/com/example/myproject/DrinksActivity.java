package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DrinksActivity extends AppCompatActivity {

    Button mangga,apel,alpukat,mineral;
    String choose = "";
    Double price = 0.00;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinks);
        Intent intent  = getIntent();

        mangga = (Button) findViewById(R.id.mangga);
        apel = (Button) findViewById(R.id.apel);
        alpukat = (Button) findViewById(R.id.alpukat);
        mineral = (Button) findViewById(R.id.mineral);


    }
    public void add_to_list(View view) {
        if(view == findViewById(R.id.mangga))
        {
            choose = choose+"Jus Mangga(Rp. 10.000)"+"\n";
            price = price + 10000;
        }
        if(view == findViewById(R.id.mineral))
        {
            choose = choose+"Air Mineral(Rp. 5000)"+"\n";
            price = price + 5000;
        }
        if(view == findViewById(R.id.apel))
        {
            choose = choose+"Jus Apel(Rp.15.000)"+"\n";
            price = price + 15000;
        }
        if(view == findViewById(R.id.alpukat))
        {
            choose = choose+"Jus Alpukat(Rp.18.000)"+"\n";
            price = price + 18000;
        }
    }

    public void myOrder(View view) {
        Intent i = new Intent(this,OrderDetails.class);
        Bundle bundle = new Bundle();
        bundle.putString("choose",choose);
        bundle.putDouble("price",price);
        i.putExtras(bundle);
        startActivity(i);
    }
}